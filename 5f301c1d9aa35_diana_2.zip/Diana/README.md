# Diana

Step 1 :: ./setup.sh

Step 2 :: python ./Backend/stage_0.py
Hit Ctrl + C if you want to terminate data extraction

Step 3 :: ./run.sh
