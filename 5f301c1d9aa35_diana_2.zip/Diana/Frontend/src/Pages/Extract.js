import React, { Component } from 'react'
import SearchBox from '../Component/SearchBox'

export class Extract extends Component {
    render() {
        return (
            <div>
                <SearchBox/>
            </div>
        )
    }
}

export default Extract
