import React from 'react';
import '../index.css'

export default function Footer() {
    return (
<div className={"text-center"} style={{color: "white !important" , backgroundColor : "black"}}>
    <br/>
    <br/>


<div id="footer" className={"text-center"} style={{color: "white !important" , backgroundColor : "black"}}>
    <div class="copyright">
        Copyright &copy; <strong>Diana Team</strong>
     


       <h6 id="footer-credits-button" className={"footer-link text-center"} style={{"color" : "white !important"}}>Devel❤per Credits</h6>
       <div  id="footer-credits-body" className={"size-xs base-semilight ink-light"}>
            <a href="souvik"><div className={"footer-credit"}>Souvik</div></a> 
            <a href="https://github.com/susanka068"><div className={"footer-credit"}>Susanka</div></a> 
        </div>
        </div>
        <br/>
        </div> 
        </div>
  )
  
}
